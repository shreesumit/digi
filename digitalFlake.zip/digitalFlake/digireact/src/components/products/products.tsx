import React from 'react';
import { Table, Input, Row, Col, Button } from 'antd';
import { BsBoxSeam } from 'react-icons/bs';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiRoutes } from '../../routes/api';
import http from '../../utils/http';
import BasePageContainer from '../layout/PageContainer';
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import './product.css';

const Product = () => {
  const [data, setData] = useState();

  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    http
      .get(apiRoutes.products)
      .then((data) => {
        setData(data.data);
      })
      .catch((err) => {
        if (err) throw err;
      });
  };

  const columns = [
    {
      title: 'Id',
      dataIndex: 'id',
      key: 'name',
    },
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Pack Size',
      dataIndex: 'pack_size',
      key: 'pack_size',
    },
    {
      title: 'Category',
      dataIndex: 'category',
      key: 'category',
    },
    {
      title: 'MRP',
      dataIndex: 'mrp',
      key: 'mrp',
    },
    {
      title: 'Image',
      dataIndex: 'img',
      key: 'img',
      render: (img: any) => (
        <div>
          <img src={`${img}`} alt="" height={50} width={50} />
        </div>
      ),
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      render: (status: any) => (
        <div>
          {status ? (
            <span style={{ color: 'green' }}>Active</span>
          ) : (
            <span style={{ color: 'red' }}> Inactive</span>
          )}
        </div>
      ),
    },
    {
      title: 'Action',
      // dataIndex: 'address',
      key: 'address',
      render: (row: any) => (
        <div>
          <button
            onClick={() => {
              editCategory(row.id);
            }}
          >
            <EditOutlined />
          </button>
          <button
            onClick={() => {
              deleteCategory(row.id);
            }}
            style={{ marginLeft: '25px' }}
          >
            <DeleteOutlined />
          </button>
        </div>
      ),
    },
  ];
  const addFunction = () => {
    navigate('/editProduct');
  };
  const editCategory = (id: any) => {
    navigate(`/editProduct/${id}`);
  };
  const deleteCategory = (id: any) => {
    http
      .delete(`${apiRoutes.deleteProduct}/${id}`)
      .then(() => {
        fetchData();
      })
      .catch((err) => {
        if (err) throw err;
      });
  };
  return (
    <BasePageContainer>
      <Row style={{ margin: '20px 0px 20px 0px' }}>
        <Col xs={24} md={1}>
          <span>
            <BsBoxSeam style={{ fontSize: 'x-large' }} />,
          </span>
        </Col>
        <Col xs={24} md={3}>
          <h1>Products</h1>
        </Col>
        <Col xs={24} md={17}>
          <div style={{ width: '70%' }}>
            <Input />
          </div>
        </Col>
        <Col xs={24} md={3}>
          <div>
            <Button className="themeColor" onClick={addFunction}>
              {' '}
              Add New
            </Button>
          </div>
        </Col>
      </Row>
      <Table dataSource={data} columns={columns} />;
    </BasePageContainer>
  );
};

export default Product;
