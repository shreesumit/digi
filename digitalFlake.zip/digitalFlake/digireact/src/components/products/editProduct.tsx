import React, { useEffect, useState } from 'react';
import { Form, Input, Select, Button, Row, Col } from 'antd';
import BasePageContainer from '../layout/PageContainer';
import { useNavigate, useParams } from 'react-router-dom';
import http from '../../utils/http';
import { apiRoutes } from '../../routes/api';

const { Option } = Select;

const AddProduct = () => {
  const [form] = Form.useForm();
  const [category, setCategory] = useState<[]>();
  const navigate = useNavigate();
  const { id } = useParams();
  if (id) {
    useEffect(() => {
      http.get(`${apiRoutes.getProduct}/${id}`).then((data) => {
        const status: any = data.data.status ? 'active' : 'inactive';
        const preFillValues = {
          status: status,
        };
        form.setFieldsValue(data.data);
        form.setFieldsValue(preFillValues);
      });
    }, []);
  }

  useEffect(() => {
    http
      .get(apiRoutes.distinctCategory)
      .then((data) => {
        setCategory(data.data.categories);
      })
      .catch((err) => {
        if (err) throw err;
      });
  }, []);

  const onFinish = () => {
    const formData = form.getFieldsValue();
    if (!id) {
      http
        .post(apiRoutes.addProduct, formData)
        .then(() => {
          navigate('/products');
        })
        .catch((err) => {
          if (err) throw err;
        });
    } else {
      http
        .patch(`${apiRoutes.editProduct}/${id}`, formData)
        .then(() => {
          navigate('/products');
        })
        .catch((err) => {
          if (err) throw err;
        });
    }
  };

  return (
    <BasePageContainer>
      <h1 style={{ margin: '20px 0px 20px 10px' }}>
        {id ? <h1>Edit Product</h1> : <h1>Add Product</h1>}
      </h1>
      <Form form={form} onFinish={onFinish} layout="vertical">
        <Row gutter={16}>
          <Col span={8}>
            <Form.Item
              name="category"
              label="Category"
              rules={[{ required: true, message: 'Please select status!' }]}
            >
              <Select>
                {category?.map((item: any) => {
                  return (
                    <Option key={item} value={`${item}`}>
                      {item}
                    </Option>
                  );
                })}
              </Select>
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="name"
              label="Product Name"
              rules={[{ required: true, message: 'Please input description!' }]}
            >
              <Input />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="pack_size"
              label="Pack Size"
              rules={[{ required: true, message: 'Please input description!' }]}
            >
              <Input />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col span={8}>
            <Form.Item
              name="mrp"
              label="MRP"
              rules={[{ required: true, message: 'Please input description!' }]}
            >
              <Input />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="img"
              label="Image"
              rules={[{ required: true, message: 'Please input description!' }]}
            >
              <Input />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="status"
              label="Status"
              rules={[{ required: true, message: 'Please select status!' }]}
            >
              <Select>
                <Option value="active">Active</Option>
                <Option value="inactive">Inactive</Option>
              </Select>
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <Col
            span={12}
            style={{
              // marginTop: 30,
              position: 'absolute',
              bottom: 1,
              right: 20,
            }}
          >
            <Form.Item>
              <Button
                style={{ display: 'inline-block' }}
                onClick={() => {
                  navigate('/products');
                }}
                htmlType="submit"
              >
                Cancel
              </Button>
              <Button
                className="themeColor btn2"
                style={{ marginLeft: 20 }}
                type="primary"
                htmlType="submit"
              >
                Save
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </BasePageContainer>
  );
};

export default AddProduct;
