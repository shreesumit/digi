import React from 'react';
import { Table, Input, Row, Col, Button } from 'antd';
import { AiOutlineCodeSandbox } from 'react-icons/ai';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiRoutes } from '../../routes/api';

import http from '../../utils/http';
import BasePageContainer from '../layout/PageContainer';
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import './category.css';

const Category = () => {
  const [data, setData] = useState();

  const navigate = useNavigate();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    http
      .get(apiRoutes.users)
      .then((data) => {
        setData(data.data);
      })
      .catch((err) => {
        if (err) throw err;
      });
  };

  const columns = [
    {
      title: 'Id',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'age',
    },
    {
      title: 'Status',
      dataIndex: 'status',
      key: 'id',
      render: (status: any) => (
        <div>
          {status ? (
            <span style={{ color: 'green' }}>Active</span>
          ) : (
            <span style={{ color: 'red' }}> Inactive</span>
          )}
        </div>
      ),
    },
    {
      title: 'Action',
      // dataIndex: 'address',
      key: 'address',
      render: (row: any) => (
        <div>
          <button
            onClick={() => {
              editCategory(row.id);
            }}
          >
            <EditOutlined />
          </button>
          <button
            onClick={() => {
              deleteCategory(row.id);
            }}
            style={{ marginLeft: '25px' }}
          >
            <DeleteOutlined />
          </button>
        </div>
      ),
    },
  ];
  const addFunction = () => {
    navigate('/addCategory');
  };
  const editCategory = (id: any) => {
    navigate(`/editCategory/${id}`);
  };
  const deleteCategory = (id: any) => {
    http
      .delete(`${apiRoutes.deleteCategory}/${id}`)
      .then((data) => {
        fetchData();
      })
      .catch((err) => {
        if (err) throw err;
      });
  };
  return (
    <BasePageContainer>
      <Row style={{ margin: '20px 0px 20px 0px' }}>
        <Col xs={24} md={1}>
          <span>
            <AiOutlineCodeSandbox className="svg" />
          </span>
        </Col>
        <Col xs={24} md={3}>
          <h1>Category</h1>
        </Col>
        <Col xs={24} md={17}>
          <div style={{ width: '70%' }}>
            <Input />
          </div>
        </Col>
        <Col xs={24} md={3}>
          <div>
            <Button className="themeColor" onClick={addFunction}>
              {' '}
              Add New
            </Button>
          </div>
        </Col>
      </Row>
      <Table dataSource={data} columns={columns} />;
    </BasePageContainer>
  );
};

export default Category;
