import React, { useEffect } from 'react';
import { Form, Input, Select, Button, Row, Col } from 'antd';
import BasePageContainer from '../layout/PageContainer';
import { useNavigate, useParams } from 'react-router-dom';
import http from '../../utils/http';
import { apiRoutes } from '../../routes/api';

const { Option } = Select;

const addCategory = () => {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const { id } = useParams();
  if (id) {
    useEffect(() => {
      http.get(`${apiRoutes.getCategory}/${id}`).then((data) => {
        const status: any = data.data.status ? 'active' : 'inactive';
        const preFillValues = {
          categoryName: data.data.name,
          description: data.data.description,
          status: status,
        };
        form.setFieldsValue(preFillValues);
      });
    }, []);
  }

  const onFinish = () => {
    const formData = form.getFieldsValue();
    if (!id) {
      http
        .post(apiRoutes.addCategory, formData)
        .then(() => {
          navigate('/category');
        })
        .catch((err) => {
          if (err) throw err;
        });
    } else {
      http
        .patch(`${apiRoutes.editCategory}/${id}`, formData)
        .then(() => {
          navigate('/category');
        })
        .catch((err) => {
          if (err) throw err;
        });
    }
  };

  return (
    <BasePageContainer>
      <Form form={form} onFinish={onFinish} layout="vertical">
        <h1 style={{ margin: '20px 0px 20px 10px' }}>
          {id ? <h1>Edit Category</h1> : <h1>Add Category</h1>}
        </h1>
        <Row gutter={16} style={{ margin: '20px 0px 20px 0px' }}>
          <Col span={8}>
            <Form.Item
              name="categoryName"
              label="Category Name"
              rules={[
                { required: true, message: 'Please input category name!' },
              ]}
            >
              <Input />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="description"
              label="Description"
              rules={[{ required: true, message: 'Please input description!' }]}
            >
              <Input />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name="status"
              label="Status"
              rules={[{ required: true, message: 'Please select status!' }]}
            >
              <Select>
                <Option value="active">Active</Option>
                <Option value="inactive">Inactive</Option>
              </Select>
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <Col
            span={12}
            style={{
              // marginTop: 30,
              position: 'absolute',
              bottom: 1,
              right: 20,
            }}
          >
            <Form.Item>
              <Button
                style={{ display: 'inline-block' }}
                onClick={() => {
                  navigate('/category');
                }}
                htmlType="submit"
              >
                Cancel
              </Button>
              <Button
                className="themeColor btn2"
                style={{ marginLeft: 20 }}
                type="primary"
                htmlType="submit"
              >
                Save
              </Button>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </BasePageContainer>
  );
};

export default addCategory;
