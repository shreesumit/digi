import { Button, Form, Input } from 'antd';

import { useNavigate } from 'react-router-dom';

import { Link } from 'react-router-dom';

const forgotPasswordStyle = {
  //   textAlign: 'right',
  marginTop: '20px',
};

const ForgotPassword = () => {
  const navigate = useNavigate();

  return (
    <>
      <h1 className="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl text-left text-opacity-30 tracking-wide">
        <img
          style={{ margin: 'auto' }}
          src="./../../../public/DF_logo-transparent2.png"
          alt=""
          width={150}
          height={150}
        />
      </h1>
      <Form
        className="space-y-4 md:space-y-6"
        // form={form}
        name="login"
        // onFinish={onSubmit}
        layout={'vertical'}
        requiredMark={false}
        initialValues={
          import.meta.env.VITE_DEMO_MODE === 'true'
            ? {
                email: 'eve.holt@reqres.in',
                password: 'password',
              }
            : {}
        }
      >
        <div>
          <Form.Item
            name="username"
            label={
              <p className="block text-sm font-medium text-gray-900">
                Enter Email
              </p>
            }
            rules={[
              {
                required: true,
                message: 'Please enter your email',
              },
              // {
              //   type: 'email',
              //   message: 'Invalid email address',
              // },
            ]}
          >
            <Input
              placeholder="name@example.com"
              className="bg-gray-50 text-gray-900 sm:text-sm py-1.5"
            />
          </Form.Item>
        </div>
        <div className="text-center">
          <Button
            className="mt-4 themeColor"
            block
            type="primary"
            size="large"
            htmlType={'submit'}
          >
            Submit
          </Button>
          <div
            onClick={() => {
              navigate('/login');
            }}
            style={forgotPasswordStyle}
          >
            <Link to="/login">back to login</Link>
          </div>
        </div>
      </Form>
    </>
  );
};

export default ForgotPassword;
