import BasePageContainer from '../layout/PageContainer';
const Dashboard = () => {
  return (
    <BasePageContainer>
      <h1 style={{ textAlign: 'center' }}>
        <div>
          <img
            style={{ margin: 'auto' }}
            src="./../../../public/DF_logo-transparent2.png"
            alt=""
            width={250}
            height={250}
          />
        </div>
        Welcome to Digitalflake admin
      </h1>
    </BasePageContainer>
  );
};

export default Dashboard;
