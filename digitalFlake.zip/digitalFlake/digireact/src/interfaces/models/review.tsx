export interface Review {
  color: string;
  year: string;
  title: string;
  star: number;
  id: number;
}
