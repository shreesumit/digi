export interface Admin {
  token: string;
}
