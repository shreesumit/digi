export const webRoutes = {
  home: '/',
  login: '/login',
  logout: '/logout',
  dashboard: '/dashboard',
  category: '/category',
  products: '/products',
  about: '/about',
  forgotPassword: '/forgotPassword',
  addCategory: 'addCategory',
  editCategory: 'editCategory/:id',
  addProducts: 'editProduct',
  editProducts: 'editProduct/:id',
};
