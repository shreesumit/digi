import { API_URL } from '../utils';

export const apiRoutes = {
  login: `${API_URL}/login`,
  addCategory: `${API_URL}/category`,
  deleteCategory: `${API_URL}/category`,
  deleteProduct: `${API_URL}/products`,
  // logout: `${API_URL}/logout`,
  users: `${API_URL}/category`,
  products: `${API_URL}/products`,
  getCategory: `${API_URL}/category`,
  getProduct: `${API_URL}/products`,
  editCategory: `${API_URL}/category`,
  editProduct: `${API_URL}/products`,
  distinctCategory: `${API_URL}/category/dist/all`,
  addProduct: `${API_URL}/products`,
  // reviews: `${API_URL}/unknown`,
};
