import { createBrowserRouter } from 'react-router-dom';
import AuthLayout from '../components/auth/AuthLayout';
import ErrorPage from '../components/errorPage';
import Layout from '../components/layout';
import Redirect from '../components/layout/Redirect';
import NotFoundPage from '../components/notfoundPage';
import { webRoutes } from './web';
import loadable from '@loadable/component';
import ProgressBar from '../components/loader/progressBar';
import RequireAuth from './requireAuth';
import Login from '../components/auth/Login';
import About from '../components/demo-pages/about';
import Product from '../components/products/products';
// import Category from '../components/category/category';

const errorElement = <ErrorPage />;
const fallbackElement = <ProgressBar />;

const Dashboard = loadable(() => import('../components/dashboard'), {
  fallback: fallbackElement,
});
const Category = loadable(() => import('../components/category/category'), {
  fallback: fallbackElement,
});
const AddCategory = loadable(
  () => import('../components/category/addCategory'),
  {
    fallback: fallbackElement,
  }
);
const AddProduct = loadable(
  () => import('../components/products/editProduct'),
  {
    fallback: fallbackElement,
  }
);
const EditProduct = loadable(
  () => import('../components/products/editProduct'),
  {
    fallback: fallbackElement,
  }
);
// const Products = loadable(() => import('../components/products/products.jsx'), {
//   fallback: fallbackElement,
// });
const ForgotPassword = loadable(
  () => import('../components/passwords/forgotpassword'),
  {
    fallback: fallbackElement,
  }
);

export const browserRouter = createBrowserRouter([
  {
    path: webRoutes.home,
    element: <Redirect />,
    errorElement: errorElement,
  },

  // auth routes
  {
    element: <AuthLayout />,
    errorElement: errorElement,
    children: [
      {
        path: webRoutes.login,
        element: <Login />,
      },
    ],
  },
  {
    element: <AuthLayout />,
    errorElement: errorElement,
    children: [
      // {
      //   path: webRoutes.changePassword,
      //   element: <ChangePassword />,
      // },
      {
        path: webRoutes.forgotPassword,
        element: <ForgotPassword />,
      },
    ],
  },

  // protected routes
  {
    element: (
      <RequireAuth>
        <Layout />
      </RequireAuth>
    ),
    errorElement: errorElement,
    children: [
      {
        path: webRoutes.dashboard,
        element: <Dashboard />,
      },
      {
        path: webRoutes.category,
        element: <Category />,
      },
      // {
      //   path: webRoutes.products,
      //   element: <Products />,
      // },
      {
        path: webRoutes.about,
        element: <About />,
      },
      {
        path: webRoutes.addCategory,
        element: <AddCategory />,
      },
      {
        path: webRoutes.editCategory,
        element: <AddCategory />,
      },
      {
        path: webRoutes.products,
        element: <Product />,
      },
      {
        path: webRoutes.addProducts,
        element: <AddProduct />,
      },
      {
        path: webRoutes.editProducts,
        element: <EditProduct />,
      },
    ],
  },

  // 404
  {
    path: '*',
    element: <NotFoundPage />,
    errorElement: errorElement,
  },
]);
