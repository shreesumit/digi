const express = require('express')
const {deleteCategory,distinctCategory, getCategory, createCategory, allCategory,updateCategory} = require('../controllers/category');
const router = express.Router()

router.route('/:id').delete(deleteCategory).get(getCategory).patch(updateCategory)
router.route('/').get(allCategory).post(createCategory);
router.route('/dist/all').get(distinctCategory)

module.exports= router