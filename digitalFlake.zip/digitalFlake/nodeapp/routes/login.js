const express = require('express')
const user = require('../controllers/login')
const router = express.Router()

router.route('/login').post(user);

module.exports= router