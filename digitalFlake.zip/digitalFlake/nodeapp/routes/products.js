const express = require('express')
const {deleteProduct, getProduct, createProduct, allProducts,updateProduct} = require('../controllers/products');
const router = express.Router()

router.route('/:id').delete(deleteProduct).get(getProduct).patch(updateProduct)
router.route('/').get(allProducts).post(createProduct);

module.exports= router