const express = require('express')
const cors = require('cors')
var path = require('path');
const con = require('./connections/mysqlConnection')
const jwt = require('jsonwebtoken');
const app = express()

app.use(cors());
app.use(express.json())
app.use('/',require('./routes/login'))
function authenticateToken(req, res, next) {

    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) {
        return res.sendStatus(401);
    }
    jwt.verify(token, 'sumit', (err, user) => {
        if (err) {
            return res.sendStatus(403);
        }
        req.user = user;
        next();
    });
}

app.use('/products',authenticateToken, require('./routes/products'))
app.use('/category',authenticateToken,  require('./routes/category'))

app.listen(4000,(err)=>{
    if(err) throw err
    console.log("server is started on 4000")
})

