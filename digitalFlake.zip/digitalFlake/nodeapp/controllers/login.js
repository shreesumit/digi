const con = require('../connections/mysqlConnection');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const user = async (req, res) => {
    try {
        const userData = req.body;

        con.query('SELECT * FROM UserCredentials WHERE username = ?', userData.username, async (err, data) => {
            if (err) {
                throw err;
            }

            if (data.length === 0) {
                return res.status(400).send('User not found');
            }

            const user = data[0]; 

            try {
                const passwordMatch = await bcrypt.compare(userData.password, user.password);
                if (passwordMatch) {
                    const accessToken = jwt.sign({ username: user.username }, 'sumit', { expiresIn: '1h' });
                    res.json({ token: accessToken });
                } else {
                    res.status(401).send('Incorrect password');
                }
            } catch (error) {
                console.error(error);
                res.status(500).send('Error during login');
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Server error');
    }
};

module.exports = user;
