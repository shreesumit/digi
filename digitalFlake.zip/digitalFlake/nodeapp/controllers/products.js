const con = require("../connections/mysqlConnection");

const getProduct = (req, res) => {
  const productId = req.params.id;
  const SELECT_PRODUCT_BY_ID_QUERY = "SELECT * FROM products WHERE id = ?";
  con.query(SELECT_PRODUCT_BY_ID_QUERY, [productId], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      if (result.length > 0) {
        res.status(200).json(result[0]); 
      } else {
        res.status(404).send("Product not found");
      }
    }
  });
};
const allProducts = (req, res) => {
  const SELECT_PRODUCTS_QUERY = "SELECT * FROM products";
  con.query(SELECT_PRODUCTS_QUERY, (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(200).json(result);
    }
  });
};

const updateProduct = (req, res) => {
  const productId = req.params.id;
  let { name, pack_size, category, mrp, img, status } = req.body;
  status = status === "active";
  const UPDATE_PRODUCT_QUERY = `UPDATE products SET name=?, pack_size=?, category=?, mrp=?, img=?, status=? WHERE id=?`;
  con.query(
    UPDATE_PRODUCT_QUERY,
    [name, pack_size, category, mrp, img, status, productId],
    (err, result) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.status(200).send("Product updated successfully");
      }
    }
  );
};

const createProduct = (req, res) => {
  let { name, pack_size, category, mrp, img, status } = req.body;
  status = status === "active";
  const INSERT_PRODUCT_QUERY = `INSERT INTO products (name, pack_size, category, mrp, img, status) VALUES (?, ?, ?, ?, ?, ?)`;
  con.query(
    INSERT_PRODUCT_QUERY,
    [name, pack_size, category, mrp, img, status],
    (err, result) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.status(200).send("Product added successfully");
      }
    }
  );
};

const deleteProduct = (req, res) => {
  const productId = req.params.id;
  const DELETE_PRODUCT_QUERY = "DELETE FROM products WHERE id=?";
  con.query(DELETE_PRODUCT_QUERY, [productId], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(200).send("Product deleted successfully");
    }
  });
};

module.exports = {
  deleteProduct,
  getProduct,
  createProduct,
  updateProduct,
  allProducts,
};
