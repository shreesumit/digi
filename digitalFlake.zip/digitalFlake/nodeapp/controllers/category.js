const con = require("../connections/mysqlConnection");

const getCategory = (req, res) => {
  const categoryId = req.params.id;
  const SELECT_CATEGORY_BY_ID_QUERY = "SELECT * FROM category WHERE id = ?";
  con.query(SELECT_CATEGORY_BY_ID_QUERY, [categoryId], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      if (result.length > 0) {
        res.status(200).json(result[0]);
      } else {
        res.status(404).send("Category not found");
      }
    }
  });
};
const allCategory = (req, res) => {
  const SELECT_CATEGORIES_QUERY = "SELECT * FROM category";
  con.query(SELECT_CATEGORIES_QUERY, (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(200).json(result);
    }
  });
};

const updateCategory = (req, res) => {
  const categoryId = req.params.id;
  let { categoryName, description, status } = req.body;
  status = status === "active";
  const UPDATE_CATEGORY_QUERY = `UPDATE category SET name=?, description=?, status=? WHERE id=?`;
  con.query(
    UPDATE_CATEGORY_QUERY,
    [categoryName, description, status, categoryId],
    (err, result) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.status(200).send("Category updated successfully");
      }
    }
  );
};

const createCategory = (req, res) => {
  let { categoryName, description, status } = req.body;
  status = status === "active";
  const INSERT_CATEGORY_QUERY = `INSERT INTO category (name, description, status) VALUES (?, ?, ?)`;
  con.query(
    INSERT_CATEGORY_QUERY,
    [categoryName, description, status],
    (err, result) => {
      if (err) {
        res.status(500).send(err);
      } else {
        res.status(200).send("Category added successfully");
      }
    }
  );
};

const deleteCategory = (req, res) => {
  const categoryId = req.params.id;
  const DELETE_CATEGORY_QUERY = "DELETE FROM category WHERE id=?";
  con.query(DELETE_CATEGORY_QUERY, [categoryId], (err, result) => {
    if (err) {
      res.status(500).send(err);
    } else {
      res.status(200).send("Category deleted successfully");
    }
  });
};

const distinctCategory = (req, res) => {
  const DISTINCT_CATEGORIES_QUERY = "SELECT DISTINCT name FROM category";
  con.query(DISTINCT_CATEGORIES_QUERY, (err, result) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      const distinctCategories = result.map((row) => row.name);
      res.status(200).json({ categories: distinctCategories });
    }
  });
};
module.exports = {
  deleteCategory,
  getCategory,
  createCategory,
  updateCategory,
  allCategory,
  distinctCategory,
};
