const mysql = require('mysql')
const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'sumit1234',
    database: 'digitalflake'
})

con.connect((err)=>{
   if(err) throw err
   console.log("Connection is successfully established");
})

module.exports = con;